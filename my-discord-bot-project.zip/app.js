require('dotenv').config();
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const axios = require('axios');
const Discord = require('discord.js');
const path = require('path');

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// إعداد الجلسة
app.use(session({
  secret: 'supersecret',
  resave: false,
  saveUninitialized: false
}));

// إعداد Passport.js
app.use(passport.initialize());
app.use(passport.session());

// مصادقة Discord
passport.use(new DiscordStrategy({
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: 'http://localhost:3000/callback',
  scope: ['identify', 'guilds']
}, function(accessToken, refreshToken, profile, done) {
  return done(null, profile);
}));

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

// صفحة تسجيل الدخول
app.get('/', (req, res) => {
  res.render('index');
});

// توجيه المستخدم لتسجيل الدخول
app.get('/login', passport.authenticate('discord'));

// توجيه بعد تسجيل الدخول
app.get('/callback', passport.authenticate('discord', {
  failureRedirect: '/'
}), (req, res) => {
  res.redirect('/dashboard');
});

// تسجيل الخروج
app.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});

// عرض السيرفرات بعد تسجيل الدخول
app.get('/dashboard', checkAuth, async (req, res) => {
  const guilds = req.user.guilds;
  res.render('dashboard', { user: req.user, guilds: guilds });
});

// اختيار الروم وارسال الرسائل
app.post('/send-message', checkAuth, async (req, res) => {
  const { guildId, channelId, messageType, messageContent } = req.body;

  const botToken = process.env.BOT_TOKEN;
  const client = new Discord.Client({ intents: ["Guilds", "GuildMessages"] });

  await client.login(botToken);

  const channel = client.channels.cache.get(channelId);
  if (!channel) return res.send("Invalid Channel");

  if (messageType === 'embed') {
    const embed = new Discord.MessageEmbed()
      .setDescription(messageContent);
    channel.send({ embeds: [embed] });
  } else {
    channel.send(messageContent);
  }

  res.send('Message sent!');
});

function checkAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/');
}

app.listen(3000, () => console.log('Server is running on http://localhost:3000'));
